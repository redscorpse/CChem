t.prefs_.set('color-palette-overrides',["#181818", "#810009", "#48513b", "#cc8b3f", "#576d8c", "#724d7c", "#5c4f4b", "#aea47f", "#555555", "#ac3835", "#a6a75d", "#dcdf7c", "#3097c6", "#d33061", "#f3dbb2", "#f4f4f4"]);
t.prefs_.set('foreground-color', "#aea47a");
t.prefs_.set('background-color', "#191c27");
t.prefs_.set('cursor-color', 'rgba(146,128,91,0.5)');
