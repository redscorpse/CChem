t.prefs_.set('color-palette-overrides',["#111A1F", "#8D5656", "#798362", "#9B9257", "#63768A", "#738C9C", "#6998B3", "#9A9A9A", "#5A5A5A", "#8D7856", "#798362", "#9B9257", "#63768A", "#738C9C", "#6998B3", "#9A9A9A"]);
t.prefs_.set('foreground-color', "#9A9A9A");
t.prefs_.set('background-color', "#111A1F");
t.prefs_.set('cursor-color', 'rgb(179,236,255,0.25)');
