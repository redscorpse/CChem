t.prefs_.set('color-palette-overrides',["#1F2229", "#D41919", "#5EBDAB", "#FEA44C", "#576d8c", "#367BF0", "#9755B3", "#49AEE6", "#E6E6E6", "#198388", "#EC0101", "#47D4B9", "#FF8A18", "#277FFF", "#962AC3", "#ffffff"]);
t.prefs_.set('foreground-color', "#ffffff");
t.prefs_.set('background-color', "#191c27");
t.prefs_.set('cursor-color', 'rgba(146,128,91,0.5)');
